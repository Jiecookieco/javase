package myanno;

public @interface MyAnno2 {
}
