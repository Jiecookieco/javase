package myanno;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
//只有一个值value可以省略
//@Target(value={ElementType.TYPE,ElementType.FIELD,ElementType.METHOD})
//用于获取类全路径名和成员方法的作用于类的注释
@Target({ElementType.TYPE})
@Retention(RetentionPolicy.RUNTIME)
public @interface MyAnno {
        String className();
        String methodName();
}
