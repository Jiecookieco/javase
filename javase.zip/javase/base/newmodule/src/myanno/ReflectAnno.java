package myanno;

import java.lang.reflect.Constructor;
import java.lang.reflect.Method;

//通过注解来代替使用配置文件传入数据
@MyAnno(className = "con1.student",methodName = "study")
public class ReflectAnno {
    public static void main(String[] args) throws Exception{
        Class<ReflectAnno> c = ReflectAnno.class;
//        class.getAnnotation(*.class);返回一个*的子类对象，
//        重写了className和methodN方法；
        MyAnno anno = c.getAnnotation(MyAnno.class);
        String className = anno.className();
        String methodName = anno.methodName();
//        反射创建类对象要先得到构造方法对象，再newInstance()
        Class<?> aClass = Class.forName(className);
        Constructor<?> con = aClass.getConstructor();
        Object o = con.newInstance();
        Method mt = aClass.getMethod(methodName);
        mt.invoke(o);

    }
}
