package myanno;

public enum Person {
    p1,p2;
}
