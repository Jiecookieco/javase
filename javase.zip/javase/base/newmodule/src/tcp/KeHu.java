package tcp;

import java.io.*;
import java.net.Socket;

public class KeHu {
    public static void main(String[] args) throws IOException {
        Socket s=new Socket("localhost",12000);
        BufferedReader br=new BufferedReader(new FileReader("newmodule\\data.txt"));
        BufferedReader brserver=new BufferedReader(new InputStreamReader(s.getInputStream()));
        BufferedWriter bw=new BufferedWriter(new OutputStreamWriter(s.getOutputStream()));
        String line;
        while((line=br.readLine())!=null)
        {
            if("草拟吗".equals(line))
            {
                break;
            }
            bw.write(line);
            bw.newLine();
            bw.flush();
        }
//        结束输出，server就不会一直等待接收数据
        s.shutdownOutput();
        System.out.println(brserver.readLine());
        s.close();
    }
}
