package tcp;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;

public class Server {
    public static void main(String[] args) throws IOException {
        File f=new File("newmodule\\server.txt");
        BufferedWriter bwf=new BufferedWriter(new FileWriter(f));
        ServerSocket ss=new ServerSocket(12000);
//        服务器要监听客户端
        Socket s = ss.accept();
        BufferedReader br=new BufferedReader(new InputStreamReader(s.getInputStream()));
        BufferedWriter bw=new BufferedWriter(new OutputStreamWriter(s.getOutputStream()));

        String line;
        while((line=br.readLine())!=null)
        {
            bwf.write(line);
            bwf.newLine();
            bwf.flush();
            System.out.println(line);
        }
        bw.write("文件传输完毕");
        bw.newLine();
        bw.flush();
        ss.close();
        bwf.close();
    }
}
