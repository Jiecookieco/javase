package con1;

import java.util.function.Function;

public class FunctionDemo {
    public static void main(String[] args) {
            String s="蔡徐坤，45";
            cutString(s,s1 -> Integer.parseInt(s1.split("，")[1]),integer -> integer+70);
    }
    private static void cutString(String s, Function<String,Integer> age,Function<Integer,Integer> ageAdd)
    {
       int i= age.andThen(ageAdd).apply(s);
        System.out.println(i);
    }

}
