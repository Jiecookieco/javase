package con1;

public class Coach {
    private int age;
    private String name;

    public Coach(int age, String name) {
        this.age = age;
        this.name = name;
    }

    public Coach() {
    }
    public void teach()
    {
        System.out.println(System.currentTimeMillis()+" 教练教学生");
    }

    @Override
    public String toString() {
        return "Coach{" +
                "age=" + age +
                ", name='" + name + '\'' +
                '}';
    }
}
