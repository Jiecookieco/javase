package con1;

import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class CollectDemo {
    public static void main(String[] args) {
        String [] arr={"六零：14","六零58：24","六零22：4","六零55：15"};
        Stream<String> arr1 = Stream.of(arr);
        Stream<String> stringStream = arr1.filter(s -> Integer.parseInt(s.split("：")[1]) < 23);
        Map<String, Integer> collect = stringStream.collect(Collectors.toMap(s -> s.split("：")[0], s -> Integer.parseInt(s.split("：")[1])));
        Set<String> strings = collect.keySet();
        for(String s:strings)
        {
            Integer i = collect.get(s);
            System.out.println(i+" "+s);
        }

    }
}
