package con1;

import myanno.MyAnno;

public class student {
    private int age;
    private String name;

//   fn+alt+insert可以快速建构造方法，shift可以全选
    public student(){

    };

    public student(int age, String name)
    {
        this.age=age;
        this.name=name;
    }

    public int getAge(){
        return age;
    }
    public String getName()
    {
        return name;
    }
    public void study()
    {
        System.out.println(System.currentTimeMillis()+" 学生在学习");
    }

    @Override
    public String toString() {
        return "student{" +
                "age=" + age +
                ", name='" + name + '\'' +
                '}';
    }
}
