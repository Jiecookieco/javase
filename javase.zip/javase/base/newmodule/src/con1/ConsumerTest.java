package con1;

import java.util.function.Consumer;

public class ConsumerTest {
    public static void main(String[] args) {
        String[] arr={"李伟，11","小米，12"};
        myinf(arr,s -> System.out.print(s.split("，")[0]),
                s -> System.out.println(s.split("，")[1] ));
//        myinf(arr,System.out::print,System.out::print);
    }
    private static void myinf(String[] arr, Consumer<String> con1, Consumer<String> con2)
    {
        for(String s:arr)
        {
            con1.andThen(con2).accept(s);
        }
    }

}
