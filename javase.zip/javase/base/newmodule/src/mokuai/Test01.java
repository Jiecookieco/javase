package mokuai;

import jumppackage.Cat;
import jumppackage.Jumpping;

public class Test01 {
    public static void main(String[] args) {
       Jumpping cxk = new Cat(12, "cxk");
       cxk.jump();
    }
}
