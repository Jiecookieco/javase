package reflet;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

public class ReflectDemo {
    public static void main(String[] args) throws Exception {
        Class<?> c = Class.forName("con1.student");
        System.out.println(c.getName());
        Constructor<?> con = c.getConstructor();
        Method[] me = c.getDeclaredMethods();
//        me是一个数组，打印结果是@4eec7777一个地址
//        System.out.println(me);
        for(Method m:me)
        {
            System.out.println(m);
        }
        Object o = con.newInstance();
        System.out.println(o);
        Field name = c.getDeclaredField("name");
//        name.set(o,"cxk");
////        在这里的成员变量name是私有变量，不能创建对象。cxk创建不行
        name.setAccessible(true);
//        跳过检查
        name.set(o,"cxk");
        System.out.println(o);
        System.out.println("----------");
        Method method = c.getMethod("getName");
        Object name1 = method.invoke(o);
        System.out.println(name1);
//        Field name = c.getDeclaredField("name");
//        name.set(o,"蔡徐坤");
//        System.out.println(o);

    }
}
