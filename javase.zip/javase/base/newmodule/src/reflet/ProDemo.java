package reflet;

import java.io.InputStream;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.util.Properties;

/**
 * @since 1.5
 * @version 1.1
 * @author jiepeng
 */
public class ProDemo {
    public static void main(String[] args) throws Exception {
//        获取配置文件
        Properties pro = new Properties();
        ClassLoader c = ProDemo.class.getClassLoader();
        InputStream rs = c.getResourceAsStream("pro.properties");
        pro.load(rs);
        rs.close();
//        获取classname、methodname
        String className = pro.getProperty("className");
        String methodName = pro.getProperty("methodName");
        Class<?> cc = Class.forName(className);
        Constructor<?> con = cc.getConstructor();
        Object o = con.newInstance();
        Method M = cc.getMethod(methodName);
        M.invoke(o);

    }
    /**
     *a 被减数
     * b 减数
     * @return 减法结果
     */
    public static int sub(int a,int b)
    {
        return a-b;
    }
}
