package udp;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;

public class SendDemo {
    public static void main(String[] args) throws IOException {
        DatagramSocket ds=new DatagramSocket();
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        String s;
        while((s=br.readLine())!=null)
        {
            if(s.equals("写完了"))
            {
                break;
            }
            DatagramPacket dp=new DatagramPacket(s.getBytes(),0,s.getBytes().length, InetAddress.getByName("localhost"),11000);
            ds.send(dp);
        }
    ds.close();
    }
}
