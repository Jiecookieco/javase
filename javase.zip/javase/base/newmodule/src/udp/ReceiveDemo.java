package udp;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;

public class ReceiveDemo {
    public static void main(String[] args) throws IOException {
//        接收的时候socket要加上端口号。
        DatagramSocket ds=new DatagramSocket(11000);
//      创建数据包
        byte[] bytes=new byte[1024];
        while(true)
        {
            DatagramPacket dp=new DatagramPacket(bytes,bytes.length);
            ds.receive(dp);
            System.out.println(new String(dp.getData(),0,dp.getLength()));
        }
//        ds.close();
    }
}
