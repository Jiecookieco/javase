package jumppackage;

public interface Jumpping {
    void jump();
}
