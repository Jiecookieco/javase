package jumppackage;

public class Cat implements Jumpping{
    private int age;
    private String name;
    public Cat() {
    }

    public Cat(int age, String name) {
        this.age = age;
        this.name = name;
    }

    @Override
    public void jump() {
        System.out.println("快乐的星猫跳了跳");
    }
}
