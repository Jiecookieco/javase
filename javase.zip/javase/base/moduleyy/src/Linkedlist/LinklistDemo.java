package Linkedlist;

import java.util.HashSet;
import java.util.LinkedList;
import java.util.Set;

public class LinklistDemo {
public static void main(String[] args) {
//        链表Linklisted
LinkedList<String> a=new LinkedList<String> ();
Set<String> a4=new HashSet<>();
a4.add("jdk");
a4.add("17");
a4.add("17");
System.out.println(a4.hashCode());
for(String i:a4)
{
    System.out.println(i);
}
a.add("讲道理");
a.add("不是人");
a.add("决斗俱乐部");
for(String i:a)
{
    System.out.println(i);
}
System.out.println(a);
a.addFirst("你好");
a.addLast("大家好");
for(String i:a)
{
    System.out.println(i);
}
}
}
