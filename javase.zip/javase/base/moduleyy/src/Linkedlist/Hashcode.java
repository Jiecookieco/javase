package Linkedlist;

import list_he.Student;

import java.util.HashSet;

public class Hashcode {
    public static void main(String[] args) {
//        顺序不能保证
        HashSet<Student> aa=new HashSet<Student>();
        Student s1 = new Student("李白", 18);
        Student s2 = new Student("李da白", 128);
        Student s3 = new Student("李xiao白", 185);
        Student s4 = new Student("李白", 18);
        aa.add(s1);
        aa.add(s2);
        aa.add(s3);
        aa.add(s4);
        for(Student s:aa)
        {
            System.out.println(s);
        }

    }
}
