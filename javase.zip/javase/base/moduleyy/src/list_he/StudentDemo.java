package list_he;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class StudentDemo {
    public static void main(String[] args) {
        List<Student> st = new ArrayList<Student>();
        Student s1 = new Student("乔碧萝", 55);
        Student s2 = new Student("蔡徐坤", 22);
        Student s3 = new Student("刘飞ID是", 58);
        st.add(s1);
        st.add(s2);
        st.add(s3);
        Iterator<Student> it = st.iterator();
        while (it.hasNext()) {
            Student temp = it.next();
            System.out.println(temp);
        }
        System.out.println("------------");
        for (int i = 0; i < st.size(); i++) {
            System.out.println(st.get(i));
        }
        System.out.println("__________________");
        for (Student s : st) {
            System.out.println(s);
        }
    }
}
