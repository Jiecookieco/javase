package Tree;

import list_he.Student;

import java.util.Comparator;
import java.util.TreeSet;

public class TreeSetDemo {
    public static void main(String[] args) {
//        new Comparator 使用了匿名内部类重写了compare方法
        TreeSet<Student> t = new TreeSet<Student>(new Comparator<Student>() {
            @Override
            public int compare(Student o1, Student o2) {
                int num = o1.getAge() - o2.getAge();
                int num1 = num == 0 ? o1.getName().compareTo(o2.getName()) : num;
                return num1;
            }
        });
        Student s1 = new Student("xiaoming",8);
        Student s2 = new Student("zhaoyun",18);
        Student s3 = new Student("dianwei",8);
        Student s4 = new Student("lvbu",28);
        t.add(s1);
        t.add(s2);
        t.add(s3);
        t.add(s4);
        for(Student s:t)
        {
            System.out.println(s);
        }

    }
}
