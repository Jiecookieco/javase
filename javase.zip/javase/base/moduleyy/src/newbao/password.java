package newbao;

import java.util.Scanner;

public class password {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("现在，请输入你的用户名");
        String host=scanner.nextLine();
        for(int i=0;i<host.length();i++)
        {
            System.out.println(host.charAt(i));
        }
        System.out.println("现在，请输入你的密码");
       String password= scanner.nextLine();
//       while(true)
//        {
//            System.out.println("请输入你的用户名：");
//            String host1=scanner.nextLine();

//            System.out.println("请输入你的密码：");
//            String password1=scanner.nextLine();
//            if(host.equals(host1)&&password1.equals(password))
//            {
//                System.out.println("登录成功");
//                break;
//            }
        }
    }


