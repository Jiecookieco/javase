package newbao;

public class Spring {
    public static void main(String[] args) {
        String a="奥利给";
        String b="奥利给";
        System.out.println(a.equals(b));
    }
}
