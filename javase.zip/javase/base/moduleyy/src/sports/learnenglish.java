package sports;
//接口属于一种行为
public interface learnenglish {
    public void speak();
}
