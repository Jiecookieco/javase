package sports;

public class Demo {
    public static void main(String[] args) {
        footballcoach fc=new footballcoach(10,"qbl");
        fc.getName();
        fc.eat();fc.speak();
        fc.teach();
    }
}
