package sports;

public class footballcoach extends coach implements learnenglish{
    public footballcoach() {
    }

    public footballcoach(int age, String name) {
        super(age, name);
    }

    @Override
    public void teach() {
        System.out.println("足球运动员教踢足球");
    }

    @Override
    public void eat() {
        System.out.println("吃香香的");
    }

    @Override
    public void speak() {
        System.out.println("我的英语很好");
    }
}
