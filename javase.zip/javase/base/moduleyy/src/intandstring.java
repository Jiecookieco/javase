import java.util.Arrays;

public class intandstring {
    public static void main(String[] args) {
        String a = "89 23 43 25 12";
        System.out.println(a);
        String[] s = a.split(" ");
        int[] as = new int[s.length];
        for (int i = 0; i < s.length; i++) {
//            字符串转整形Integer.parseint
            as[i] = Integer.parseInt(s[i]);
        }
        Arrays.sort(as);
        StringBuilder ass = new StringBuilder();
        for (int i = 0; i < s.length; i++)
        {
            if(i==s.length-1)
                ass.append(as[i]);
            else
                ass.append(as[i]).append(" ");
        }
        a=ass.toString();
        System.out.println(a);

    }
}
