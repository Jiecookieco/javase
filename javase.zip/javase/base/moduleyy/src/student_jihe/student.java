package student_jihe;

public class student {
    private int age;
    private String name;

//   fn+alt+insert可以快速建构造方法，shift可以全选
    private student(){

    };
    public student(int age,String name)
    {
        this.age=age;
        this.name=name;
    }
    public int getAge(){
        return age;
    }
    public String getName()
    {
        return name;
    }
}
