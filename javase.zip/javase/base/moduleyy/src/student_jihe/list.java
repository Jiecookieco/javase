package student_jihe;

import java.util.ArrayList;
import java.util.Scanner;

public class list {
    public static void main(String[] args) {
        ArrayList<student> ss=new ArrayList<student>();
         setss(ss);
        setss(ss);
        setss(ss);
        setss(ss);
        get(ss);

    }
    public static void setss(ArrayList<student> ss)
    {
        Scanner sc = new Scanner(System.in);
        System.out.println("输入姓名");
        String sname = sc.nextLine();
        System.out.println("输入年龄");
        int sage=sc.nextInt();
        ss.add(new student(sage,sname));

    }
    public static void get(ArrayList<student> ss)
    {
        for(int i=0;i< ss.size();i++)
        {
            System.out.println(ss.get(i).getAge()+"  "+ss.get(i).getName());
        }
    }

}