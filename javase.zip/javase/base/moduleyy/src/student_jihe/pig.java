package student_jihe;

public class pig {
    int weight;
    String pigname;

    public pig() {
    }

    public pig(int weight, String pigname) {
        this.weight = weight;
        this.pigname = pigname;
    }

    public int getWeight() {
        return weight;
    }

    public String getPigname() {
        return pigname;
    }
}
