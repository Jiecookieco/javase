package student_jihe;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class date {
    public static void main(String[] args) throws ParseException {
        Date d=new Date();
        SimpleDateFormat sdf=new SimpleDateFormat("yyyy年MM月dd日 HH：mm：ss");
        String s= sdf.format(d);
        System.out.println(d);
        System.out.println(s);
        String ss="2938年12月23日 09：10：55";
        Date d1=sdf.parse(ss);
        System.out.println(d1);
    }
}
