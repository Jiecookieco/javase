package filedemo;

import java.io.File;

public class GetFIle {
    public static void main(String[] args) {
        File f1 = new File("E:\\Project1");
        GetFilepath(f1);
    }
    public static void GetFilepath(File exp)
    {
        File[] files = exp.listFiles();
        if(files!=null)
        {
            for(File f:files)
            {
                if(f.isDirectory())
                {
                    GetFilepath(f);
                }
                else
                {
                    System.out.println(f.getName()+" "+f.getAbsolutePath());
                }
            }
        }
    }
}
