package filedemo;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class FiletupianDemo {
    public static void main(String[] args) throws IOException {
        FileInputStream fis = new FileInputStream("E:\\java\\mytupian.jpg");
        FileOutputStream fos= new FileOutputStream("moduleyy\\new.jpg");
        byte[] by=new byte[1024];
        int len;
        while((len=fis.read(by))!=-1)
        {
            fos.write(by,0,len);
        }
        fis.close();
        fos.close();
    }
}
