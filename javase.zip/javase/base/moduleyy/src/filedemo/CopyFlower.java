package filedemo;

import java.io.*;

//对象和方法的第二个单词首字母要大写
public class CopyFlower {
    public static void main(String[] args) throws IOException {
        File srcFile = new File("E:\\testfirst");
        File desFile = new File("D:\\");
        long start=System.currentTimeMillis();
        copyFolder(srcFile, desFile);
        long end=System.currentTimeMillis();
        System.out.println("共耗时："+(end-start)+"毫秒");

    }

    //复制文件夹
    private static void copyFolder(File srcFile, File destFile) throws IOException {
        if (srcFile.isDirectory()) {
            File newfloder = new File(destFile, srcFile.getName());
            if (!newfloder.exists()) {
                newfloder.mkdir();
            }
            File[] files = srcFile.listFiles();
            for (File f : files) {
                copyFolder(f, newfloder);
            }
        } else {
//            这里需要newFile对象不能用newfloder
            File newFile = new File(destFile, srcFile.getName());
            copyFile(srcFile,newFile);
        }
    }


    private static void copyFile(File f, File newfloder) throws IOException {
        FileInputStream fis = new FileInputStream(f);
        FileOutputStream fos = new FileOutputStream(newfloder);
        byte[] by = new byte[1024];
        int len;
        while ((len = fis.read(by)) != -1) {
            fos.write(by, 0, len);
        }
        fis.close();
        fos.close();
    }
}

