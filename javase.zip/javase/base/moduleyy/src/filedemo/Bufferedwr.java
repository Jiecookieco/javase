package filedemo;

import java.io.*;

//字符缓冲流
public class Bufferedwr {
    public static void main(String[] args) throws IOException {
        BufferedReader br=new BufferedReader(new FileReader("E:\\helloworld.java"));
        BufferedWriter bw = new BufferedWriter(new FileWriter("moduleyy\\helloworld.java"));
//        char[] ch=new char[1024];
//        int len;
//        while((len= br.read(ch))!=-1)
//        {
//            bw.write(ch,0,len);
//        }
//使用字符缓冲流特有方法 r.readline/w.newline.w.flush
        String s=new String();
        while((s=br.readLine())!=null)
        {
            bw.write(s);
            bw.newLine();
            bw.flush();
        }

        br.close();
        bw.close();
    }
}
