package filedemo;

import java.io.*;
//创建内部缓冲区,最快的传输方法(字节)
public class Bufferinou {
    public static void main(String[] args) throws IOException {
        BufferedInputStream bis = new BufferedInputStream(new FileInputStream("E:\\java\\test.mp4"));
        BufferedOutputStream bos=new BufferedOutputStream(new FileOutputStream("moduleyy\\testok.mp4"));
        byte[] bys=new byte[1024];
        int len;
        long start=System.currentTimeMillis();
        while((len=bis.read(bys))!=-1)
        {
            bos.write(bys,0,len);
        }
        long end=System.currentTimeMillis();
        System.out.println("共用时"+(end-start)+"毫秒");
//        把资源关闭
        bis.close();
        bos.close();

    }
}
