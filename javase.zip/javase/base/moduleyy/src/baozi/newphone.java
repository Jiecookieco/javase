package baozi;

public class newphone extends phone {
    private int price;
    private String brand;
//    方法重写
    @Override
    public void call(String name)
    {
        System.out.println("给"+name+"发短信");
        super.call(name);
    }
    public  void ring(String name)
    {
        System.out.println("ringring"+name);
    }


}
