package baozi;



import java.util.Random;
import java.util.Scanner;

//测试类要psvm。对象是战内存，类是堆内存。
public class phoneDemo {
    public static void main(String[] args) {
//        phone p = new phone();
//        newphone pp = new newphone();
//        p.call("蔡徐坤");
//        System.out.println("_______________");
//        pp.call("雷军");
        phone p=new newphone();
        p.call("xiaoming");
        plusphone pp=new plusphone();
        newphone ppp=new newphone();
        newphone p1=(newphone)p;
        p1.ring("cxk");
        operte(pp,"蔡徐坤");operte(ppp,"蔡徐坤");

////        p是对象，phone是类；
//        phone p = new phone(2000, "小米");
////        p.setPrice(2999);
////        p.setBrand("黑鲨");
//        System.out.println(p.getPrice());
//        System.out.println(p.getBrand());
//        Random ss=new Random();
////        alt加enter可以自动给你弄个左边变量
//        int i = ss.nextInt(12);
//        System.out.println(i);
//        Scanner string =new Scanner(System.in);
////        alt加enter可以自动给你弄个左边变量
//        String s = string.nextLine();
//        System.out.println(s);
    }
//    同一个类里面，方法要有static，这里是使用了多态，参数为父类的phone，输入参数时使用子类的new，plusphone，可以调用不同的方法重写。
    public static void operte(phone p,String name)
    {
        p.call(name);
    }
}
