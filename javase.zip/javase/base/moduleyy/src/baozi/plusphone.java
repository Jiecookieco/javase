package baozi;

public class plusphone extends phone {
    @Override
    public void call(String name) {
        System.out.println("给"+name+"发微信");
        super.call(name);
    }
}
