package baozi;

//类的属性和方法
public class phone {
    private int price;
    private String brand;
    public void call(String name)
    {
        System.out.println("给"+name+"打电话");
    }
    public phone(){}
    //    （api）类就可以构造方法。。
    public phone(int price,String brand) {
//        System.out.println("我准备好了！！！！")
        this.brand=brand;
        this.price=price;
    }

    //    用private其他类使用需调用方法，可给数值添加限制。
//    public void setPrice(int a) {
//        price = a;
//    }
//
//    //    this可以指向成员变量。。。。
//    public void setBrand(String brand) {
//        this.brand = brand;
//    }

    public int getPrice() {
        return price;
    }

    public String getBrand() {
        return brand;
    }
}
