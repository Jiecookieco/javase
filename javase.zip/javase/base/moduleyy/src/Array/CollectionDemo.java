package Array;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

public class CollectionDemo {
    public static void main(String[] args) {
//        多态创建Collection对象。
        Collection<String> c=new ArrayList<String> ();
        c.add("fu");
        c.add("c");
        c.add("k");
        Iterator<String> ii = c.iterator();
        while(ii.hasNext())
        {
            String s=ii.next();
            System.out.println(s);
        }
    }
}
