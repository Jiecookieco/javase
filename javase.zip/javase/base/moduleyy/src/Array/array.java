package Array;

import java.util.Arrays;

public class array {
    public static void main(String[] args) {
        int[] a={13,2,23,45,25};
        System.out.println(Arrays.toString(a));
        Arrays.sort(a);
        System.out.println(Arrays.toString(a));

    }

}
