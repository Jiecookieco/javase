package Array;

public class Exception {
    public static void main(String[] args) {
        method();
    }

    public static void method() {
        try {
            int[] arr = {1, 2, 3};
            System.out.println(arr[3]);//ArrayIndexOutOfBoundsException
        } catch (ArrayIndexOutOfBoundsException e) {
           e.printStackTrace();
        }

    }
}
