package Doudizhu;

import java.util.*;

////创建hashmap对象，保存牌号《integer和牌《字符串
//创建Arraylist对象，保存牌号《integer
//创建字符串数组，牌色&牌值《字符串
//两个循环导入牌值，和牌号到map，以及牌号到list
//通过循环把牌号导入到已创建的三个牌手以及三张牌的牌底的treeset对象
//通过treeset对象遍历牌号从而遍历牌值；
public class DOUDIZHu {
    public static void main(String[] args) {
        HashMap<Integer,String> hm=new HashMap<>();
        ArrayList<Integer> arrayList=new ArrayList<>();
        String [] color={"♠","♥","◆","♣"};
        String [] number={"3","4","5","6","7","8","9","10","J","Q","K","A","2"};
        int te=1;
        for(String number1:number)
        {
            for(String color1:color)
            {
                hm.put(te,number1+color1);
                arrayList.add(te);
                te++;
            }
        }
        hm.put(te,"小王");
        arrayList.add(te);
        te++;
        hm.put(te,"大王");
        arrayList.add(te);
        TreeSet<Integer> 地主=new TreeSet<>();
        TreeSet<Integer> 农民1=new TreeSet<>();
        TreeSet<Integer> 农民2=new TreeSet<>();
        TreeSet<Integer> 牌底=new TreeSet<>();
//        用Collections.shuffle打乱牌堆，这就是为什么要创建ArrayList对象的原因。
        Collections.shuffle(arrayList);
//        System.out.println(arrayList);
        int i=0;
        for(Integer nu:arrayList)
        {
            if(i<arrayList.size()-3) {
                if (i % 3 == 0)
                    地主.add(nu);
                else if (i % 3 == 1)
                    农民1.add(nu);
                else if (i % 3 == 2)
                    农民2.add(nu);
            }
            else
            {
            牌底.add(nu);
            牌底.add(nu);
            牌底.add(nu);}
            i++;
        }

        show(地主,hm,"大地主");
        show(农民1,hm,"小农民1");
        show(农民2,hm,"小农民2");
        show(牌底,hm,"剩下");

    }
    public static void show(TreeSet<Integer> name,HashMap<Integer,String> hm,String na)
    {
        System.out.println(na+"的牌为：");
        for(Integer i1:name)
        {
            String s = hm.get(i1);
            System.out.print(s+" ");
        }
        System.out.println();
    }
}
