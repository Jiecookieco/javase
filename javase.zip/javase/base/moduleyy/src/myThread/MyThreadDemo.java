package myThread;

public class MyThreadDemo {
    public static void main(String[] args) {
        MyThread mt1=new MyThread("老八");
        MyThread mt2=new MyThread("六舅");
        mt1.start();
        mt2.start();
        System.out.println(Thread.currentThread().getName());

    }

}
