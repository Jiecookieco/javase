package myThread;
//类名两个单词都首字母大写
public class MyThread extends Thread{
    public MyThread() {
    }

    public MyThread(String name) {
        super(name);
    }

    @Override
    public void run() {
        for(int i=1;i<101;i++)
        {
            System.out.println(getName()+":我打了你"+i+"次");
        }
    }
}
