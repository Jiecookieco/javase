package Stringbuilder;

import java.util.Scanner;

public class myreserve {
    public static void main(String[] args) {
        System.out.println("请输入你的字符串：");
        Scanner sc = new Scanner(System.in);
        String ss=sc.nextLine();
        System.out.println(reserve_(ss));
    }
    public static String reserve_(String s)
    {
         return new StringBuilder(s).reverse().toString();
    }
}
