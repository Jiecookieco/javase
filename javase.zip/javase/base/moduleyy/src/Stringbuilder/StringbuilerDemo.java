package Stringbuilder;

public class StringbuilerDemo {
    public static void main(String[] args) {
        int[] arr={1,2,4};
        System.out.println(arrytostring(arr));
    }

    public  static String arrytostring(int[] arr)
    {
        StringBuilder stringbuiler = new StringBuilder();
        stringbuiler.append("[");
        for(int i=0;i< arr.length;i++)
        {
            if(i==arr.length-1)
            {
                stringbuiler.append(arr[i]);
            }
            else
            {
                stringbuiler.append(arr[i]+",");
            }
        }
        stringbuiler.append("]");
        String sb=stringbuiler.toString();
        return sb;
    }
}

