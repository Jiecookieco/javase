package map;

import java.util.Scanner;
import java.util.Set;
import java.util.TreeMap;
//计算字符串各字符的个数
public class TreemapDemo {
    public static void main(String[] args) {
        TreeMap<Character,Integer> tm=new TreeMap<>();
        Scanner sc=new Scanner(System.in);
        String s = sc.nextLine();
        for(int i=0;i<s.length();i++)
        {
             char c = s.charAt(i);
             Integer value =tm.get(c);
             if(value==null)
             {
                 value=1;
                 tm.put(c,value);
             }
             else{
                 value++;
                 tm.put(c,value);
             }
        }
        Set<Character> as = tm.keySet();
        for(Character a:as)
        {
            System.out.println(a+"("+tm.get(a)+")");
        }

    }
}
