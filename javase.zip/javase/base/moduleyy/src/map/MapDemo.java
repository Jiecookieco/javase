package map;

import list_he.Student;

import java.util.HashMap;
import java.util.Set;

public class MapDemo {
    public static void main(String[] args) {
        HashMap<String, Student> map = new HashMap<>();
        Student s1 = new Student("李元芳", 23);
        Student s2 = new Student("李小玲", 13);
        Student s3 = new Student("张芳", 2);
        map.put("1616",s1);
        map.put("1617",s2);
        map.put("1618",s3);
        Set<String> ke = map.keySet();
        for(String s:ke)
        {
            Student ss = map.get(s);
            System.out.println(ss+"，学号为"+s);
        }
    }
}
