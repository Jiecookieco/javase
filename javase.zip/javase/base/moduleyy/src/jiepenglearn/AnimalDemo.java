package jiepenglearn;

public class AnimalDemo {
        public static void main(String[] args) {
            Animal a=new Pig(1,"浩");
            System.out.println(a.getAge()+","+a.getName());
            a=new Monkey(2,"滑");
            System.out.println(a.getAge()+","+a.getName());
        }
}
