package jiepenglearn;

public class Pig extends Animal{
    public Pig() {
    }

    public Pig(int age, String name) {
        super(age, name);
    }

    @Override
    public void eat() {
        System.out.println("猪供白菜");
    }
}
