package jiepenglearn;

public class Monkey extends Animal{
    public Monkey() {
    }

    public Monkey(int age, String name) {
        super(age, name);
    }

    @Override
    public void eat() {
        System.out.println("猴子吃香蕉");
    }
}
