package runableDE;

public class Box {
    private boolean state=false;
    private int milk;
    public synchronized void put(int milk)  {
        if(state)
        {
            try {
                wait();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
            this.milk = milk;
            System.out.println("第"+milk+"瓶牛奶放入");
            state=!state;
            notifyAll();

    }
    public synchronized void get()  {
        if(!state)
        {
            try {
                wait();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

            System.out.println("第"+milk+"瓶牛奶拿出");
            state=!state;
            notifyAll();

    }

}
