package runableDE;

public class Comuser implements Runnable{
    private Box b;
    public Comuser(Box box) {
        this.b=box;
    }

    @Override
    public void run() {
        while (true)
        {
            b.get();
        }
    }
}
