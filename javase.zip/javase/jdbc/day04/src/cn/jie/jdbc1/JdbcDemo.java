package cn.jie.jdbc1;

import javax.swing.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class JdbcDemo {
//    导入mysql驱动jar包

public static void main(String[] args)  throws Exception{
    //    注册驱动
    Class.forName("com.mysql.jdbc.Driver");
//    获取数据库连接对象
    Connection con = DriverManager.getConnection("jdbc:mysql:///db2","root","root");
//    定义sql语句
    String s = "update accout set money=1500 ";
//    定义执行语句的对象 statement
    Statement statement = con.createStatement();
//    执行sql
    int i = statement.executeUpdate(s);
//    executeUpdate返回影响的行数
    System.out.println(i);
}
}
