package cn.jie.jdbc1;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
//需要释放connection和statement，用finally
public class JdbcDemo2 {
    public static void main(String[] args) {
//        提升作用域，在finally也能close
//        把con和stm先在try外面赋值为null
        Connection con=null;
        Statement stm=null;
        try {
//            Class.forName("com.mysql.jdbc.Driver");
//            url,用户名，密码
//            con = DriverManager.getConnection("jdbc:mysql:///db2","root","root");
            con = JdbcUtils.getCon();
            stm = con.createStatement();
            String sql="insert into users values(null,'1212','6565')";
            System.out.println("影响的行数："+stm.executeUpdate(sql));
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        finally {
                    JdbcUtils.close(con,stm,null);
//            stm.close();避免stm为null就close，产生空指针异常
//            if(stm!=null)
//            {
//                try {
//                    stm.close();
//                } catch (SQLException e) {
//                    e.printStackTrace();
//                }
//            }
//            if(con!=null)
//            {
//                try {
//                   con.close();
//                } catch (SQLException e) {
//                    e.printStackTrace();
//                }
//            }
        }
    }
}
