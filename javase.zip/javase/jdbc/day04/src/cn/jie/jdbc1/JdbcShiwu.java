package cn.jie.jdbc1;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class JdbcShiwu {
    public static void main(String[] args) {
        Connection con=null;
        PreparedStatement pstm=null;
        try{
             con = JdbcUtils.getCon();
             con.setAutoCommit(false);
            String sql1="update accout set money=money-? where id=?";
            String sql2="update accout set money=money+? where id=?";
            pstm = con.prepareStatement(sql1);
            pstm.setDouble(1,500);
            pstm.setInt(2,2);
            pstm.executeUpdate();
            int i=3/0;
            pstm=con.prepareStatement(sql2);
            pstm.setDouble(1,500);
            pstm.setInt(2,3);
            pstm.executeUpdate();
            con.commit();
        } catch (Exception e) {
            try {
                if(con!=null) {
                    con.rollback();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            e.printStackTrace();
        }
        finally {
            JdbcUtils.close(con,pstm,null);
        }
    }
}
