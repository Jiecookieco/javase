package cn.jie.jdbc1;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;

//用prepareStatement
public class JdbcLogPlus {
    static Scanner sc = new Scanner(System.in);
    private static String username = null;
    private static String password = null;

    //    main函数也是一个static，class的变量需要static，main才能调用
    public static void main(String[] args) {
        log();
    }

    public static void log() {
        Connection con = null;
        ResultSet rs = null;
        PreparedStatement pstmt = null;
        read();
        while (true) {
            if (username.length() * password.length() == 0) {
                System.out.println("请输入你的用户名和密码");
                try {
                    Thread.sleep(2000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                read();
            } else {
                try {
                    con = JdbcUtils.getCon();
                    String sql = "select * from users where user= ? and pw= ?";
                    pstmt = con.prepareStatement(sql);
                    pstmt.setString(1, username);
                    pstmt.setString(2, password);
//                  prepareStatement不能在execute里使用sql
                    rs = pstmt.executeQuery();
                    if (rs.next()) {
                        System.out.println("登录成功");
                        break;
                    } else {
                        System.out.println("用户名或密码错误");
                        read();
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                } finally {
                    JdbcUtils.close(con, pstmt, rs);
                }
            }
        }


    }

    public static void read() {
        System.out.println("请输入你的用户名");
        username = sc.nextLine();
        System.out.println("请输入你的密码");
        password = sc.nextLine();
    }
}
