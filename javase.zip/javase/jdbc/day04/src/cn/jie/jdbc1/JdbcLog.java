package cn.jie.jdbc1;

import java.sql.*;
import java.util.Scanner;

public class JdbcLog {
    static Scanner sc=new Scanner(System.in);
    private static String username=null;
    private static String password=null;
//    main函数也是一个static，class的变量需要static，main才能调用
    public static void main(String[] args) {
        log();
    }
    public static void log()
    {
        Connection con=null;
        ResultSet rs=null;
        Statement stm=null;
        read();
        while(true) {
            if (username.length() * password.length()==0) {
                System.out.println("请输入你的用户名和密码");
                try {
                    Thread.sleep(2000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                read();
            } else
            {

                try {
                    con = JdbcUtils.getCon();
                    stm = con.createStatement();
                    String sql = "select * from users where user='" + username + "' and pw='" + password + "'";
                    rs = stm.executeQuery(sql);
                    if(rs.next())
                    {
                        System.out.println("登录成功");
                        break;
                    }
                    else{
                        System.out.println("用户名或密码错误");
                        read();
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                } finally {
                            JdbcUtils.close(con,stm,rs);

                }
            }
        }


    }
    public static void read()
    {
        System.out.println("请输入你的用户名");
        username = sc.nextLine();
        System.out.println("请输入你的密码");
        password=sc.nextLine();
    }

}
