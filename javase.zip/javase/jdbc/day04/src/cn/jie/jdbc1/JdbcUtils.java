package cn.jie.jdbc1;

import java.io.FileReader;
import java.io.IOException;
import java.net.URL;
import java.sql.*;
import java.util.Properties;

public class JdbcUtils {
//    使用static才能被静态代码块读取
    static Connection con=null;
    private static String url;
    private static String user;
    private static String password;
    private static String driver;

//使用静态代码块,只会运行一次来读取文件,只能try不能throws
    static{
//        读取资源文件
        Properties pro = new Properties();
//        Properties的load和。getpro方法
        try {
//            使用Classloader得到动态的文件路径
            ClassLoader cl = JdbcUtils.class.getClassLoader();
            URL resource = cl.getResource("jdbc.properties");
            String path = resource.getPath();
            pro.load(new FileReader(path));
        } catch (IOException e) {
            e.printStackTrace();
        }
        url = pro.getProperty("url");
        user = pro.getProperty("user");
        password = pro.getProperty("password");
        driver=pro.getProperty("driver");
//        注册驱动
        try {
            Class.forName(driver);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
    public static Connection getCon()
    {

        try {
            con = DriverManager.getConnection(url, user, password);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return con;
    }


    public static void close(Connection con, Statement stm, ResultSet rs)
    {

        if(rs!=null)
        {
            try {
                rs.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        if(stm!=null)
        {
            try {
                stm.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        if(con!=null)
        {
            try {
                con.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

}
