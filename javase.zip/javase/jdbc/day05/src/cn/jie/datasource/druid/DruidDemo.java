package cn.jie.datasource.druid;

import com.alibaba.druid.pool.DruidDataSourceFactory;

import javax.sql.DataSource;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.util.Properties;

public class DruidDemo {
    public static void main(String[] args) throws Exception {
        Properties pro = new Properties();
        InputStream ra = DruidDemo.class.getClassLoader().getResourceAsStream("druid.properties");
        pro.load(ra);
        ra.close();
        DataSource ds = DruidDataSourceFactory.createDataSource(pro);
        Connection con = ds.getConnection();
        System.out.println(con);
    }
}
