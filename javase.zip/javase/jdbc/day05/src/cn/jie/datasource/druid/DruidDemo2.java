package cn.jie.datasource.druid;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class DruidDemo2 {
        private static Connection con=null;
        static PreparedStatement pstm=null;
    public static void main(String[] args) {
        try {
            con = DruidUtil.getConnection();
            String sql="insert into accout values(null,?,?)";
            pstm = con.prepareStatement(sql);
            pstm.setDouble(1,5222);
            pstm.setString(2,"刘丽丽");
            pstm.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        finally {
            DruidUtil.close(con,pstm,null);
        }
    }
}
