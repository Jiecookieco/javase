package cn.jie.jdbctemplate;

import cn.jie.datasource.druid.DruidUtil;
import cn.jie.domain.Account;
import org.junit.Test;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;

import java.util.List;
import java.util.Map;

public class JdbcTemplateQuery {
    static JdbcTemplate tem=new JdbcTemplate(DruidUtil.getDataSource());
    @Test
    public  void test1()
    {
        String sql="select * from accout where id=1";
        Map<String, Object> map = tem.queryForMap(sql);
        System.out.println(map);
    }
    @Test
    public void test2()
    {
        String sql="select * from accout";
        List<Map<String, Object>> maps = tem.queryForList(sql);
        for(Map<String, Object> map:maps)
        {
            System.out.println(map);
        }
    }
    @Test
    public void test3()
    {
        String sql="select * from accout";
        List<Account> query = tem.query(sql, new BeanPropertyRowMapper<Account>(Account.class));
        for(Account a:query)
        {
            System.out.println(a);
        }
    }
    @Test
    public void test4()
    {
        String sql="select count(id) from accout";
        Object o = tem.queryForObject(sql, Object.class);
        System.out.println(o);
    }
}
