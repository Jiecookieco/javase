package cn.jie.jdbctemplate;

import cn.jie.datasource.druid.DruidUtil;
import com.alibaba.druid.util.JdbcUtils;
import org.springframework.jdbc.core.JdbcTemplate;

public class JDBCTemplateDemo {
    public static void main(String[] args) {
//        JdbcTemplate依赖于连接池
//        ctrl+p显示参数类型
        JdbcTemplate template = new JdbcTemplate(DruidUtil.getDataSource());
        int i = template.update("update emp set ename='蔡徐坤'where ename=?", "林冲");
    }
}
